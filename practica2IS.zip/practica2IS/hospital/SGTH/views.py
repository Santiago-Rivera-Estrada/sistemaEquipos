from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def home(request):
    return render(request, 'pages/home.html')   
def inicio(request):
    return HttpResponse("<h1>Bienvenido a mi sitio web<h1>")        
def equipos(request):
    return HttpResponse("<h1>Pagina de listar equipos<h1>")  