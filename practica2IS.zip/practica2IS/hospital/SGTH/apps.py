from django.apps import AppConfig


class SgthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'SGTH'
